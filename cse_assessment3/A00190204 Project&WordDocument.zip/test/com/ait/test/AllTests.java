package com.ait.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CoffeeMachineTest.class, RecipeTest.class })
public class AllTests {

}
