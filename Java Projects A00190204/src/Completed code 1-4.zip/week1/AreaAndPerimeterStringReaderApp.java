package week1;

import java.util.Scanner;

public class AreaAndPerimeterStringReaderApp 
{

	public static void main(String[] args) 
	{
		//Declare Variable
		String width,length;
		//Create a scanner object.
		Scanner sc=new Scanner(System.in);

		//Display a welcome message
		System.out.println("Welcome to the Area and Perimeter Calculator.\n");

		//Print out asking for Length.
		System.out.print("Enter Length Details: ");

		//Take in next String.
		length=sc.nextLine();

		//Print out asking for Width.
		System.out.print("Enter Width Details: ");

		//Take in next String.
		width=sc.nextLine();

		//Print out Length
		System.out.println("Length: "+length);
		
		//Print out Width
		System.out.println("Width: "+width);

		//Print out a blank line.
		System.out.println();

		//Free up Scanner.
		sc.close();
	}

}