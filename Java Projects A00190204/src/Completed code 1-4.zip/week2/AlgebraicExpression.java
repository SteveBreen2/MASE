package week2;

public class AlgebraicExpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int xValue=2;
		 int aValue=3;
		
		double value= (aValue*Math.pow(xValue,3)+7);
		System.out.println("Value: "+value);
	}

}
