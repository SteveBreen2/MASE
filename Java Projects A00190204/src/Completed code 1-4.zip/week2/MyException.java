package week2;

class MyException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8485746770437201711L;

	public MyException(String messageParam){
		super(messageParam);
	}
}
